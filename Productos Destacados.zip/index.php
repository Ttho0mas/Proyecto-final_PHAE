<!DOCTYPE html>
<html>
<head>
  <title>Productos Destacados</title>
  <link rel="stylesheet" type="text/css" href="css.css">
</head>
<body>
  <h1>PRODUCTOS DESTACADOS</h1>
  <div class="product-container">
    <?php include 'productos.php'; ?>
  </div>
</body>
</html>
