
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bd_pintureriaarcoiris";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
      die("Conexión fallida: " . $conn->connect_error);
    }

    $sql = "SELECT id_producto, marca, precio, imagen, descripcion FROM Productos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

      while($row = $result->fetch_assoc()) {
        echo '<div class="product-item">';
        echo '<a href="detalle_producto.php?id=' . $row["id_producto"] . '">';
        echo '<img src="' . $row["imagen"] . '" alt="' . $row["marca"] . '">';
        echo '<h2>' . $row["marca"] . '</h2>';
        echo '<p class="price">$' . $row["precio"] . '</p>';
        echo '<p class="description">' . $row["descripcion"] . '</p>';
        echo '</a>';
        echo '</div>';
      }
    } else {
      echo "No se encontraron productos.";
    }

    $conn->close();
?>
