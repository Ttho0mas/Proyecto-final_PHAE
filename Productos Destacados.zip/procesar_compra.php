<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_producto = $_POST['id_producto'];
    $cantidad = $_POST['cantidad'];
    $nombre = $_POST['nombre'];
    $email = $_POST['email'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bd_pintureriaarcoiris";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    $sql_update_stock = "UPDATE Productos SET stock_cantidad = stock_cantidad - $cantidad WHERE id_producto = $id_producto";
    if ($conn->query($sql_update_stock) === TRUE) {
        echo "Compra procesada exitosamente.";
    } else {
        echo "Error al procesar la compra: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Método de solicitud no válido.";
}
?>
